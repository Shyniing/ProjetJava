/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abyss;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 *
 * @author clem-
 */
public class PileCartes {
   
    private ArrayList<Cartes> mesCartes;

    public PileCartes() {
        this.mesCartes = remplirCartes();
    }
    
    public ArrayList<Cartes> remplirCartes(){
       List<Cartes> retour = new ArrayList();
        retour.add(new CartesPeuples(couleur.bleu,5));
        retour.add(new CartesPeuples(couleur.vert,5));
        retour.add(new CartesPeuples(couleur.jaune,5));
        retour.add(new CartesPeuples(couleur.violet,5));
        retour.add(new CartesPeuples(couleur.rouge,5));
        
        for(int i=0;i<2;i++){
            retour.add(new CartesPeuples(couleur.bleu,4));
            retour.add(new CartesPeuples(couleur.vert,4));
            retour.add(new CartesPeuples(couleur.jaune,4));
            retour.add(new CartesPeuples(couleur.violet,4));
            retour.add(new CartesPeuples(couleur.rouge,4)); 
        }
        for(int i=0;i<3;i++){
            retour.add(new CartesPeuples(couleur.bleu,3));
            retour.add(new CartesPeuples(couleur.vert,3));
            retour.add(new CartesPeuples(couleur.jaune,3));
            retour.add(new CartesPeuples(couleur.violet,3));
            retour.add(new CartesPeuples(couleur.rouge,3));
            retour.add(new CartesPeuples(couleur.bleu,2));
            retour.add(new CartesPeuples(couleur.vert,2));
            retour.add(new CartesPeuples(couleur.jaune,2));
            retour.add(new CartesPeuples(couleur.violet,2));
            retour.add(new CartesPeuples(couleur.rouge,2));
            
        }
        for(int i=0;i<4;i++){
            retour.add(new CartesPeuples(couleur.bleu,1));
            retour.add(new CartesPeuples(couleur.vert,1));
            retour.add(new CartesPeuples(couleur.jaune,1));
            retour.add(new CartesPeuples(couleur.violet,1));
            retour.add(new CartesPeuples(couleur.rouge,1)); 
        }
        for(int i=0;i<6;i++){
            retour.add(new Monstres());
        }
        Collections.shuffle(retour);
        return (ArrayList<Cartes>) retour;
    }

    public ArrayList<Cartes> getMesCartes() {
        return mesCartes;
    }
    

}
