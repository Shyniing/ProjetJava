/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abyss;

import java.io.FileNotFoundException;
import java.util.ArrayList;

/**
 *
 * @author Vincent
 */
public class Plateau {
    //Les attributs actuellement disponible dans la partie
    
    private ArrayList<Lieu> lieuDispo;
    private ArrayList<Seigneur> seigneursDispo;
    private int menace;
    
    private Conseil conseil;
    private ArrayList<Cartes> cheminExplo;
    // Les pioches
    
    private PileLieu piocheLieu;
    private PileSeigneur piocheSeigneur;
    private PileCartes piocheExplo;

    public Plateau() throws FileNotFoundException {
        this.piocheExplo = new PileCartes();
        this.piocheSeigneur = new PileSeigneur();
        this.piocheLieu = new PileLieu();
        
        this.cheminExplo = new ArrayList<Cartes>();
        this.conseil = new Conseil();
        this.menace = 1;
        
        this.lieuDispo = new ArrayList<Lieu>();
        this.seigneursDispo = new ArrayList<Seigneur>();
    }
    
    
}
