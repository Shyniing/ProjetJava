/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abyss;

/**
 *
 * @author Vincent
 */
public class Seigneur { 
    private int nb_pts_vic;
    private String nom;
    private int id_pouvoir;
    boolean estGradien;
    private int nb_Peuples;
    private int valcap;
    private couleur c;


    public Seigneur(int nb_pts_vic, String nom, int id_pouvoir, boolean estGradien, int nb_Peuples, int valcap, couleur coul) {
        this.nb_pts_vic = nb_pts_vic;
        this.nom = nom;
        this.id_pouvoir = id_pouvoir;
        this.estGradien = estGradien;
        this.nb_Peuples = nb_Peuples;
        this.valcap = valcap;
        this.c = coul;
    }
    
    
    public String toString(){
        return "nom :"+this.nom+"\n nb points :"+this.nb_pts_vic+" id: "+this.id_pouvoir+"estGardien : "+this.estGradien+" nb de peuples : "+this.nb_Peuples+" Valeur de capture :"+this.valcap+" Couleur :"+this.c;
    }

    public int getNb_pts_vic() {
        return nb_pts_vic;
    }

    public String getNom() {
        return nom;
    }

    public int getId_pouvoir() {
        return id_pouvoir;
    }

    public boolean isEstGradien() {
        return estGradien;
    }

    public int getNb_Peuples() {
        return nb_Peuples;
    }

    public int getValcap() {
        return valcap;
    }

    public couleur getCouleur() {
        return c;
    }

    
    
    
}
