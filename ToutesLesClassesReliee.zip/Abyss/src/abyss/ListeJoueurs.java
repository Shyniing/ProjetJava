/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abyss;

import java.util.ArrayList;

/**
 *
 * @author clem-
 */
public class ListeJoueurs {
    private ArrayList<Joueur> listeJoueur;

    public ListeJoueurs(int nbJoueurs) {
        this.listeJoueur = new ArrayList<Joueur>();
        for(int i =0;i<nbJoueurs;i++){
        this.listeJoueur.add(new Joueur(i+1));
        }
    }
    public ListeJoueurs() {
        this.listeJoueur = new ArrayList<Joueur>();
        for(int i =0;i<4;i++){
        this.listeJoueur.add(new Joueur(i+1));
        }
    }

    public ArrayList<Joueur> getListeJoueur() {
        return listeJoueur;
    }
    
    public String toString(){
        return this.listeJoueur.toString();
    }
}
