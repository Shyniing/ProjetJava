/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abyss;

import java.util.ArrayList;

/**
 *
 * @author clem-
 */
public class Conseil {
    private ArrayList<CartesPeuples> allieBleu;
    private ArrayList<CartesPeuples> allieVert;
    private ArrayList<CartesPeuples> allieRouge;
    private ArrayList<CartesPeuples> allieJaune;
    private ArrayList<CartesPeuples> allieViolet;

    public Conseil() {
        this.allieBleu = new ArrayList<CartesPeuples>();
        this.allieVert = new ArrayList<CartesPeuples>();
        this.allieRouge = new ArrayList<CartesPeuples>();
        this.allieJaune = new ArrayList<CartesPeuples>();
        this.allieViolet = new ArrayList<CartesPeuples>();
    }
    
    
}
