/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abyss;

/**
 *
 * @author Vincent
 */
public abstract class Cartes {
    
    
    
    public abstract boolean estMonstre();
    public abstract String toString();
}

enum couleur {
    rouge,
    jaune,
    vert,
    bleu,
    violet,
    blanc;
}

class CartesPeuples extends Cartes {

    private int valeur;
    private couleur c;

    public CartesPeuples(couleur c, int valeur) {
        this.valeur = valeur;
        this.c = c;
    }

    public int getValeur() {
        return valeur;
    }

    public couleur getCouleur() {
        return c;
    }
    public boolean estMonstre(){
    return false;
}
    public String toString(){
        return this.c+" "+this.valeur;
    }
    
}

class Monstres extends Cartes {

    public Monstres() {
    }
    public boolean estMonstre(){
    return true;
}
    public String toString(){
        return "Monstre";
    }
}