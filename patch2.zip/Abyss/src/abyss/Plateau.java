/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abyss;

import java.util.ArrayList;

/**
 *
 * @author Vincent
 */
public class Plateau {
    //Les attributs actuellement disponible dans la partie
    
    private ArrayList<Lieu> lieuDispo;
    private ArrayList<Seigneur> seigneursDispo;
    private int menace;
    
    private ArrayList<ArrayList<Cartes>> conseil;
    private ArrayList<Cartes> cheminExplo;
    // Les pioches
    
    private ArrayList<Lieu> piocheLieu;
    private ArrayList<Seigneur> piocheSeigneur;
    private ArrayList<Cartes> piocheExplo;

    public ArrayList<ArrayList<Cartes>> getConseil() {
        return conseil;
    }

    public ArrayList<Cartes> getPiocheExplo() {
        return piocheExplo;
    }

    public int getMenace() {
        return menace;
    }

    public void setMenace(int menace) {
        this.menace = menace;
    }
    
    // methode qui vide la piste d'exploration pour envoyer les cartes au conseil 
    public void ToConseil(){};
    
}
